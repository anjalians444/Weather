import 'package:flutter/material.dart';

class ApiServices{
  static String base_url = "https://api.weatherapi.com/v1/current.json?key=527ce7f89c924b1194c132938221501&q=";
  static String key = "";
  static String city_url = "&q=";
  static String address = "";
  static String api = "&aqi=no";
 // static String url = base_url+Golbalkeys.home+api;
}