import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:weather/globalkey.dart';
import 'package:weather/model/LocationModel.dart';
import 'package:weather/model/currenmodel.dart';
import 'package:weather/services/Apiservices.dart';

class WebServices{

 static Future<void>weatherRequest(BuildContext context,String url,List<LocationModel> loclist,List<Current> currlist, List<Condition> conlist)async{
    var response=await http.get(Uri.parse(url),
        // body:convert.jsonEncode(request),
        headers: {
          "content-type": "application/json",
          "accept": "application/json"
        });
    print("res"+response.body);
    // final parsed = json.decode(response.body).cast<Map<String, dynamic>>();
    Map<String, dynamic> jsonResponse = await json.decode(utf8.decode(response.bodyBytes));
    print("jsonres"+jsonResponse.toString());
    if (response.statusCode == 200) {
      print("response${response.body}");
      var list = jsonResponse['location'];
      LocationModel locationModel;
      locationModel = LocationModel.fromJson(list);
      loclist.add(locationModel);
      print("listlength${list.toString()}");
      print("....${list['name']}");
      print("....${loclist[0].name}");


      var current = jsonResponse['current'];
      print("name${current.toString()}");

      Current currentmodel;

      currentmodel = Current.fromJson(current);
        currlist.add(currentmodel);

      print("currentlist${currlist.length}");
      print("tempc....${currlist[0].tempC}");
      var condition = current['condition'];
      Condition con;

      con = Condition.fromJson(condition);
      conlist.add(con);
      print("condition${condition}");
    } else {
      throw Exception('error');
    }
    // ucardlist.clear();
    // Map<String, dynamic> jsonResponse = await convert.jsonDecode(utf8.decode(response.bodyBytes));
    // print("response...${jsonResponse}");
    // if(jsonResponse['error_code'] == 0 && jsonResponse['status'] == true){
    //   print("jresponse...${jsonResponse}");
    //   List list = jsonResponse['cards'];
    //   UserCardModel userCardModel;
    //   list.forEach((element) {
    //     userCardModel = UserCardModel.fromJson(element);
    //     ucardlist.add(userCardModel);
    //   });
    //   print("listlength${ucardlist.length}");
    //
    // }
  }

}