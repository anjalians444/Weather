import 'package:flutter/material.dart';
import 'package:weather/screens/Home.dart';

class Golbalkeys{
  static GlobalKey home =GlobalKey<HomeState>();
}