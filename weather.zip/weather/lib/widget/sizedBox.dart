import 'package:flutter/material.dart';

const double hBox = 5.0;
const double hBox1 = 10.0;
const double hBox2 = 20.0;
const double hBox3 = 30.0;
const double hBox4 = 40.0;
const double hBox5 = 80.0;
const double hBox6 = 60.0;

const double wBox = 5.0;
const double wBox1 = 10.0;
const double wBox2 = 20.0;
const double wBox3 = 40.0;
const double wBox5 = 65.0;
const double wBox4 = 80.0;


const SizedBox hSizedBox = SizedBox(height: hBox);
const SizedBox hSizedBox1 = SizedBox(height: hBox1);
const SizedBox hSizedBox2 = SizedBox(height: hBox2);
const SizedBox hSizedBox3 = SizedBox(height: hBox3);
const SizedBox hSizedBox4 = SizedBox(height: hBox4);
const SizedBox hSizedBox5 = SizedBox(height: hBox5);
const SizedBox hSizedBox6 = SizedBox(height: hBox6);

const SizedBox wSizedBox = SizedBox(width: wBox);
const SizedBox wSizedBox1 = SizedBox(width: wBox1);
const SizedBox wSizedBox2 = SizedBox(width: wBox2);
const SizedBox wSizedBox3 = SizedBox(width: wBox3);
const SizedBox wSizedBox4 = SizedBox(width: wBox4);
const SizedBox wSizedBox5 = SizedBox(width: wBox5);